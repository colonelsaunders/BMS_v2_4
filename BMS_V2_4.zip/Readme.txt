Board specs - 

4 layer board, 1oz outer, 2 oz inner copper
0.062" thickness
ENIG board finish
Black soldermask

Layer definitions - 

assemblytop.pho - Assembly drawing (derived from board top)
assemblybottom.pho - Assembly drawing (derived from board bottom)
bottomcopper.pho - Bottom copper layer
bottompastemask.pho - Bottom Paste Mask layer
bottomsilkscren.pho - Bottom Silk Screen layer
bottomsoldermask.pho - Bottom Solder Mask layer
drilldrawing.pho - Drill Drawing
drills.drl - Drill File
layer2copper.pho - Internal Layer 2 copper (adjacent to top layer)
layer3copper.pho - Internal Layer 3 copper (adjacent to bottom layer)
topcopper.pho - Top copper payer
toppastemask.pho - Top Paste Mask layer
topsilkscreen.pho - Top Silk Screen layer
topsoldermask.pho - Top Solder Mask layer

Included files -

BMS_v2_4_BOM.xlsx
BMS_v2_4_XYRS.slsx
